var ajax = new XMLHttpRequest();
var method = "GET";
var url = "wyniki.json";
var dni = []; // tablica zawierająca dane z klucza "dzien" 
var iloscwezwan = []; // tablica zawierająca dane z klucza "zdarzenia" 
ajax.open(method,url);
ajax.send();
ajax.onreadystatechange = function()
{
    if (this.readyState == 4 && this.status == 200)
        {
            var data = JSON.parse(this.responseText);
            for (var a = 0; a < data.length; a++)
                {
                    var dzien = data[a].dzien;
                    var zdarzenia = data[a].zdarzenia;
                    iloscwezwan.push(zdarzenia);
                    dni.push(dzien);
                   
                }
            
    var tworzwykres = wykres.getContext('2d');
    var config = {
       type: 'line',
       data: {
          labels: dni,
          datasets: [{
             label: 'zdarzenia',
             data: iloscwezwan,
             backgroundColor: 'rgba(0, 119, 204, 0.3)'
          }]
       }
    };

    var wykresik = new Chart(tworzwykres, config);

        }
}

 