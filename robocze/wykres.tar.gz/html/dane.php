<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tabela";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT dzien, zdarzenia FROM wykres";
$result = $conn->query($sql);
$dbdata = array();
  while ( $row = $result->fetch_assoc())  {
	$dbdata[]=$row;
  }

$conn->close();
print json_encode($dbdata);
$filehandle = fopen ('wyniki.json','w');
fwrite($filehandle, json_encode($dbdata));
fclose($filehandle);
?>